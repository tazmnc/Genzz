package dev.minhtaz.genzfabled.placeholder;

import dev.minhtaz.genzfabled.listener.FabledTrackerListener;
import dev.minhtaz.genzfabled.tracker.PlayerTracker;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

public final class GenzExpansion extends PlaceholderExpansion {
    private static final String LAST_DAMAGE     = "combat_last_damage";
    private static final String MANA_USE        = "player_mana_use";
    private static final String DAMAGE_SUFFIX   = "_combat_last_damage";
    private static final String MANA_USE_SUFFIX = "_mana_use";
    private static final String NO_VALUE        = "0";

    private final PlayerTracker tracker = new PlayerTracker();
    private volatile boolean hooked;

    @Override
    public @NotNull String getIdentifier() {
        return "genz";
    }

    @Override
    public @NotNull String getAuthor() {
        return "MinhTaz";
    }

    @Override
    public @NotNull String getVersion() {
        Package pkg = GenzExpansion.class.getPackage();
        String version = pkg == null ? null : pkg.getImplementationVersion();
        return version == null ? "dev" : version;
    }

    @Override
    public String getRequiredPlugin() {
        return "Fabled";
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        hookFabledEvents();

        String id = params.toLowerCase(Locale.ROOT);

        if (id.equals(LAST_DAMAGE)) {
            return player == null ? NO_VALUE : format(tracker.getLastDamage(player.getUniqueId()));
        }
        if (id.equals(MANA_USE)) {
            return player == null ? NO_VALUE : format(tracker.getLastManaUse(player.getUniqueId()));
        }

        if (id.endsWith(DAMAGE_SUFFIX)) {
            Player target = findOnline(params, DAMAGE_SUFFIX);
            return target == null ? NO_VALUE : format(tracker.getLastDamage(target.getUniqueId()));
        }
        if (id.endsWith(MANA_USE_SUFFIX)) {
            Player target = findOnline(params, MANA_USE_SUFFIX);
            return target == null ? NO_VALUE : format(tracker.getLastManaUse(target.getUniqueId()));
        }

        return null;
    }

    // Deferred: /papi reload rebuilds this class in a fresh loader, so only the instance that actually serves requests owns the listener.
    private void hookFabledEvents() {
        if (hooked) {
            return;
        }

        Plugin placeholderApi = Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
        if (placeholderApi == null) {
            return;
        }

        if (Bukkit.isPrimaryThread()) {
            registerListener(placeholderApi);
        } else {
            Bukkit.getScheduler().runTask(placeholderApi, () -> registerListener(placeholderApi));
        }
    }

    private void registerListener(Plugin placeholderApi) {
        if (hooked) {
            return;
        }
        hooked = true;

        try {
            Bukkit.getPluginManager().registerEvents(new FabledTrackerListener(tracker), placeholderApi);
        } catch (Throwable error) {
            placeholderApi.getLogger().warning(
                    "[genz] Could not hook the Fabled events, placeholders will stay at " + NO_VALUE + ": " + error);
        }
    }

    private static Player findOnline(String params, String suffix) {
        String name = params.substring(0, params.length() - suffix.length());
        return name.isEmpty() ? null : Bukkit.getPlayerExact(name);
    }

    private static String format(double value) {
        return BigDecimal.valueOf(value)
                .setScale(2, RoundingMode.HALF_UP)
                .stripTrailingZeros()
                .toPlainString();
    }
}
