package dev.minhtaz.genzfabled.listener;

import dev.minhtaz.genzfabled.tracker.PlayerTracker;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import studio.magemonkey.fabled.api.event.PhysicalDamageEvent;
import studio.magemonkey.fabled.api.event.PlayerManaLossEvent;
import studio.magemonkey.fabled.api.event.SkillDamageEvent;
import studio.magemonkey.fabled.api.event.TrueDamageEvent;

/**
 * Tracks the values behind the placeholders. Listening at MONITOR gives the
 * final damage, after Fabled applied its attribute/defense scaling.
 */
public final class FabledTrackerListener implements Listener {
    private final PlayerTracker tracker;

    public FabledTrackerListener(PlayerTracker tracker) {
        this.tracker = tracker;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPhysicalDamage(PhysicalDamageEvent event) {
        trackDamage(event.getDamager(), event.getDamage());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSkillDamage(SkillDamageEvent event) {
        trackDamage(event.getDamager(), event.getDamage());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTrueDamage(TrueDamageEvent event) {
        trackDamage(event.getDamager(), event.getDamage());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onManaLoss(PlayerManaLossEvent event) {
        if (event.getAmount() <= 0) {
            return;
        }

        Player player = event.getPlayerData().getPlayer();
        if (player != null) {
            tracker.setLastManaUse(player.getUniqueId(), event.getAmount());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        tracker.clear(event.getPlayer().getUniqueId());
    }

    private void trackDamage(LivingEntity damager, double damage) {
        if (damage > 0 && damager instanceof Player player) {
            tracker.setLastDamage(player.getUniqueId(), damage);
        }
    }
}
