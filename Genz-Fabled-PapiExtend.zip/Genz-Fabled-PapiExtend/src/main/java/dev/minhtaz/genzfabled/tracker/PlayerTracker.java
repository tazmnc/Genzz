package dev.minhtaz.genzfabled.tracker;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerTracker {
    private final Map<UUID, Double> lastDamage = new ConcurrentHashMap<>();
    private final Map<UUID, Double> lastManaUse = new ConcurrentHashMap<>();

    public void setLastDamage(UUID playerId, double damage) {
        lastDamage.put(playerId, damage);
    }

    public double getLastDamage(UUID playerId) {
        return lastDamage.getOrDefault(playerId, 0.0);
    }

    public void setLastManaUse(UUID playerId, double amount) {
        lastManaUse.put(playerId, amount);
    }

    public double getLastManaUse(UUID playerId) {
        return lastManaUse.getOrDefault(playerId, 0.0);
    }

    public void clear(UUID playerId) {
        lastDamage.remove(playerId);
        lastManaUse.remove(playerId);
    }
}
